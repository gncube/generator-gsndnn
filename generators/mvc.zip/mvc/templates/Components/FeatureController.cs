
using System.Collections.Generic;
using DotNetNuke.Entities.Modules;
using DotNetNuke.Services.Search;

namespace <%= fullNamespace %>.Components
{
    public class <%= extensionName %>Controller 
    {

    }
}